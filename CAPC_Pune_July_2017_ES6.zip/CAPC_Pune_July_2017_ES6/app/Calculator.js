const PI = 3.14;

export default PI;

export function Add(x, y){
    return x + y;
}

export function Subtract(x, y) {
    return x - y;
}

//export default Add;