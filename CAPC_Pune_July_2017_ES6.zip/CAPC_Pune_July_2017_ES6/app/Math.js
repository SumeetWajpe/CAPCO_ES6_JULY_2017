import PI, {Subtract,Add} from './Calculator';

console.log('The addition is : ' + Add(10,80));