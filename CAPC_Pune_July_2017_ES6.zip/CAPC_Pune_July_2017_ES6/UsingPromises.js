function GetData(){
    return new Promise(function(resolve,reject){
            // make ajaxified request
            // if success -> resolve !
            // if error -> reject !
        var requestObj = new XMLHttpRequest();
        requestObj.onreadystatechange = function  (){

            if(requestObj.readyState == 4 && requestObj.status == 200){
                // success !

                

                resolve(requestObj.responseText); // response from the server !

            }else if(requestObj.readyState == 4 && requestObj.status != 200){
                // error !
                reject('Some Error occurred !' + requestObj.statusText);
            }
        }// eof onreadystatechange

        requestObj.open('GET','https://jsonplaceholder.typicode.com/posts');
        requestObj.send(); // make ajax request !
    });// eof Promise();
}